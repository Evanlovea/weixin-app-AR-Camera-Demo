
Page({
  data: {
    Code: '' //用户加密的参数
  },
  addCard: function () {
    var that = this //获取Code参数
    var card = 'p-TKW0kXEaTB0PRCjxUsgQqhnOAc'
    wx.request({
      url: 'https://ioetake.com/WeiXinDemo_war/wx.do',
      data: {
        card: card
      },
      method: 'GET',
      success: function (res) {
        var res = res.data;
        console.log(res);
        var card = res.card_id;
        var timestamp = res.timestamp;
        var signature = res.signature;
        var nonceStr = res.nonce_str;
        wx.addCard({
          cardList: [
            {
              cardId: 'p-TKW0kXEaTB0PRCjxUsgQqhnOAc',
              cardExt: '{"code": "", "openid": "", "timestamp": ' + timestamp + ', "signature":"' + signature + '","nonce_str": ' + nonceStr + '}'
            }
          ],

          success: function (ress) {
            console.log(ress)
            //console.log(ress.cardList) // 卡券添加结果
            //console.log(ress.cardList[0].cardId)
            that.data.Code = ress.cardList[0].code
            //console.log(Code)        
            wx.setStorageSync('cardList', res.cardList)//结果缓存
          }
        })
        // var en = success
        // wx.request({
        //   url: 'http://cbipap.natappfree.cc/Wx/success.do',
        //   data:{
        //     success : en
        //   }
        // })
      }
    })
  },
  access: function () {
    var en = 'success'
    wx.request({
      url: 'https://ioetake.com/WeiXinDemo_war/wx.do',
      data: {
        success: en
      }
    })
  },
  openCard: function (res) {
    wx.request({
      url: 'https://ioetake.com/WeiXinDemo_war/wx.do',
      data: {},
      method: 'GET',
      success: function (res) {
        console.log(res)
        console.log(res.data)

        wx.openCard({
          cardList: [
            {
              cardId: res.data.card_id,
              code: res.data.code
            }
          ],
          success: function (res) {
          }
        })
      }
    })
  },
  openID: function () {
    wx.login({
      success: function (res) {
        var code = res.code;//登录凭证
        //console.log(code);  code的值
        wx.request({
          url: 'https://ioetake.com/WeiXinDemo_war/wx.do',  // 获取openid
          data: {
            code: code
          }
       
        })
        console.log(code);

      },

    })
  },
  next: function () {

  },

  /**
   * 生命周期函数--监听页面加载
   * 微信获取openid
   */
  onLoad: function (options) {
    // wx.login({
    //   success: function (res) {
    //     var code = res.code;//登录凭证
    //     //console.log(code);
    //     wx.request({
    //       url: 'https://ioetake.com/WeiXinDemo_war/wx.do',  // 获取openid
    //       data: {
    //         code: code
    //       }
    //     })
    //     if (code) {
    //       //2、调用获取用户信息接口
    //       //发起网络请求
    //     } else {
    //       console.log('获取用户登录态失败！' + r.errMsg)
    //     }
    //   },
    //   fail: function () {
    //     callback(false)
    //   }
    // });
    wx.login({
      success: function (res) {
       
        var service_url = 'https://ioetake.com/WeiXinDemo_war/wx.do?code' + res.code;//需要将服务器域名添加到小程序的request合法域名中，而且必须是https开头  
   
        wx.request({
          url: service_url,
          data: {},
          method: 'GET',
          success: function (res) {
            var that=res.code;
            console.log(that)
            console.log(res);
            if (res.data != null && res.data != undefined && res.data != '') {
              wx.setStorageSync("openid", res.data.openid);//将获取的openid存到缓存中  
            }
          }
        });
      }
    });  
  }
})
