//index.js
//获取应用实例
var app = getApp();
Page({
  data: {
    animationData: {},
    cardInfoList: [{
      cardUrl: 'http://wx1.sinaimg.cn/mw690/006hyGWCly1fknu4aybbmj31kw11x0w7.jpg',
      cardInfo: {
        cardTitle: 'About it',
        cardInfoMes: ['AR扫一扫', '点击进入扫码页面', '扫出你意想不到的惊喜']
      }
    
    }]
  },
  //事件处理函数
  slidethis: function (e) {
    console.log(e);
    var animation = wx.createAnimation({
      duration: 300,
      timingFunction: 'cubic-bezier(.8,.2,.1,0.8)',
    });
    var self = this;
    this.animation = animation;
    this.animation.translateY(-420).rotate(-5).translateX(0).step();
    this.animation.translateY(62).translateX(25).rotate(0).step();
    this.setData({
      animationData: this.animation.export()
    });
    setTimeout(function () {
      var cardInfoList = self.data.cardInfoList;
      var slidethis = self.data.cardInfoList.shift();
      self.data.cardInfoList.push(slidethis);
      self.setData({
        cardInfoList: self.data.cardInfoList,
        animationData: {}
      });
    }, 350);
  },
  buythis: function (e) {
    console.log(e);
    app.buyDetail = this.data.cardInfoList[e.target.id];
    var that = this;
    wx.scanCode({
      success: (res) => {
        if (res.result == 'first') {
          wx.navigateTo({
            url: '../first/first',
          });
        } else if (res.result == 'erlou') {
          wx.navigateTo({
            url: '../erlou/erlou',
          });
        } else if (res.result == 'sanlou') {
          wx.navigateTo({
            url: '../sanlou/sanlou',
          });
        } else if (res.result == 'silou') {
          wx.navigateTo({
            url: '../silou/silou',
          });
        } else if (res.result == 'wulou') {
          wx.navigateTo({
            url: '../wulou/wulou',
          });
        }
        else{
          wx.showModal({
            title: '提示',
            content: '您可能扫描了错误的二维码哦！',
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定')
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      },
      fail:function(){
        wx.showModal({
          title: '提示',
          content: '扫描失败',
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定');
             /* wx.navigateBack({
                delta: 1
              })*/
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    })
  },
  onLoad: function () {
    
  }
})