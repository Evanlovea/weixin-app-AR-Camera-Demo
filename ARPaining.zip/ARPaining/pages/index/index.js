Page({
  data: {
    imgList: [
      { url: 'http://wx2.sinaimg.cn/mw690/006hyGWCly1fkneaa4ou1j30ym0egnao.jpg', text: 'AR扫一扫',navigator_url:'../saoma/saoma', id: 1 },
      { url: 'http://wx1.sinaimg.cn/mw690/006hyGWCly1fknea9tr70j30ro0c24jb.jpg', text: 'AR涂鸦', navigator_url: '../tuya/tuya', id: 2 },
      { url: 'http://wx2.sinaimg.cn/mw690/006hyGWCly1fkneaavmx8j31kw0o5whk.jpg', text: '更多功能即将上线...', navigator_url: '../saoma/saoma', id: 3 } 
     ]
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})