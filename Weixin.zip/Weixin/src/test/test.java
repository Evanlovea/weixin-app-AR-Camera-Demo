package test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class test {
    public static void main(String[] args) {
//        OutputStream aFileout = null;
//        //输出
//        try {
//
//            aFileout = new FileOutputStream("data.txt");
//            String content = "123456";
//            aFileout.write(content.getBytes());
//
//            content = "继续";
//            aFileout.write(content.getBytes());
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }finally {
//            if(aFileout != null){
//                try {
//                    aFileout.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
       // String timestamp = String.valueOf(date.get/1000);
    }
}
