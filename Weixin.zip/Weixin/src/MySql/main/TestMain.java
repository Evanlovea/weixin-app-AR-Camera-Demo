package com.hubo.main;

import MySql.bean.Card_Id;
import MySql.dao.Card_IdDao;

import java.util.ArrayList;

/**
 * Created by hubo on 2017/11/12
 */
public class TestMain {

}
