package util;

import java.io.*;

public class AccessTextFile {
    /**
     * 写入文本
     * @param buffer    文本内容
     * @param name  文本名字
     */
//    public void writeFromBuffer(Object buffer, String name){
//        OutputStream Fileout = null;
//        String buffer1 = buffer.toString();
//        buffer1 += "\n";
//        try {
//            Fileout = new FileOutputStream(name,true);   //将文本输出到name下的文件
//            Fileout.write(buffer1.getBytes());
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if(Fileout != null){
//                try {
//                    Fileout.close();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//
//    }

//
//    public static void main(String[] args) {
//        String text = "asdasd";
//        String name = "en.txt";
//        writeFromBuffer(text,name);
//    }
}
